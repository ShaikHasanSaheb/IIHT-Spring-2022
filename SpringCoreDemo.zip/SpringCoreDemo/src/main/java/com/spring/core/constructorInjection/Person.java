package com.spring.core.constructorInjection;

public class Person {

	private String name;
	private int personId;
	private Certi certi;

	public Person(String name, int personId, Certi certi) {
		this.name = name;
		this.personId = personId;
		this.certi = certi;
	}

	// for required pattern of Output we can write our own pattern in toString
	@Override
	public String toString() {
		return this.name + " :  " + this.personId + " { " + this.certi.name + " } ";
	}

//	@Override
//	public String toString() {
//		return "Person [name=" + name + ", personId=" + personId + ", certi=" + certi + "]";
//	}

}
