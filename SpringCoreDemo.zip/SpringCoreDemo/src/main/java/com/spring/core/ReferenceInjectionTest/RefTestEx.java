package com.spring.core.ReferenceInjectionTest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.core.ReferenceInjection.Object1;

public class RefTestEx {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/spring/core/ReferenceInjectionTest/RefTestConfig.xml");

		StudentDetails std = (StudentDetails) context.getBean("studentDetails");

		System.out.println(std.getStudentName());
		System.out.println(std.getStudentClass());
		System.out.println(std.getStudentAge());
		System.out.println(std.getStudentCity());

		System.out.println(std.getStudentSub().getSubject1());
		System.out.println(std.getStudentSub().getSubject2());
		System.out.println(std.getStudentSub().getSubject3());
		System.out.println(std.getStudentSub().getSubject4());

	}
}
