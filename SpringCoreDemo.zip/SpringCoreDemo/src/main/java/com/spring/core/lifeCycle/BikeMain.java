package com.spring.core.lifeCycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BikeMain {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/spring/core/lifeCycle/config.xml");
		Motorbike m1 = (Motorbike) context.getBean("motorbike1");
		System.out.println(m1);
		context.registerShutdownHook();

	}

}
