package com.spring.core.lifeCycle;

public class Motorbike {

	private String name;
	private Double price;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("Setting the Name");
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		System.out.println("Setting the price");
		this.price = price;
	}

	public Motorbike() {
		super();
	}

	@Override
	public String toString() {
		return "Motorbike [name=" + name + ", price=" + price + "]";
	}

	public void init() {
		System.out.println("this bean has init() instialized");
	}
	
	public void destroy() {
		System.out.println("this bean has destroy() instialized");
	}
}
