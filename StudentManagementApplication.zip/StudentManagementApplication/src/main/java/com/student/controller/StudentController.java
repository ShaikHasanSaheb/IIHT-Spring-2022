package com.student.controller;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.entity.Student;
import com.student.services.IStudentService;

@RestController
public class StudentController {

	@Autowired
	IStudentService iStudentService;

	@GetMapping("/helloworld")
	public String helloworld() {
		return "Hey Hasan Welcome to Spring Boot Section";
	}

//	Controller for Adding the Student
	@PostMapping("/addStudent")
	Integer createStudent(@RequestBody Student student) {
		Integer id = iStudentService.saveStudent(student);
		System.out.println(id);
		return id;
	}
	
	@GetMapping("/student/{id}")
	public Optional<Student> getStudent(@PathVariable Integer id) {
		Optional<Student> studentDetails = iStudentService.getStudent(id);
		return studentDetails;
	}
	
	@GetMapping("/allStudents")
	public List<Student> getAllStudents(){
		List<Student> allStudents = iStudentService.getAllStudent();
		return allStudents;
		
	}

}
