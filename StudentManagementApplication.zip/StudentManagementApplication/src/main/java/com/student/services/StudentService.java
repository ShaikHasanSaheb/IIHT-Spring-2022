package com.student.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.Student;
import com.student.repo.IStudentRepositary;

@Service
public class StudentService implements IStudentService {

	@Autowired
	IStudentRepositary iStudentRepositary;

	@Override
	public Integer saveStudent(Student student) {
		Student saveStudent = iStudentRepositary.save(student);
		return saveStudent.getsId();
	}

	@Override
	public Optional<Student> getStudent(Integer id) {
		return iStudentRepositary.findById(id);
	}

	@Override
	public List<Student> getAllStudent() {
		List<Student> allStudents = iStudentRepositary.findAll();
		return allStudents;
	}

}
