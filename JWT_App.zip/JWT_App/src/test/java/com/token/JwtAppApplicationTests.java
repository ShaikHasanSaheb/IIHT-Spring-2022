package com.token;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
