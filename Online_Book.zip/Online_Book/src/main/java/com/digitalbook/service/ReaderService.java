package com.digitalbook.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.digitalbook.model.BookDetails;
import com.digitalbook.model.Payment;

public interface ReaderService {
	
	List<BookDetails> searchbooks(String category, String authorname, BigDecimal price, String publisherName);

	Payment buyBook(Payment payment, Integer bookId);

	Optional<BookDetails> getPurchasedBookByPayId(Integer paymentId);

}
