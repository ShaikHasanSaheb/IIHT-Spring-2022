package com.digitalbook.service.Impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import javax.swing.text.html.Option;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Optionals;
import org.springframework.stereotype.Service;

import com.digitalbook.model.BookDetails;
import com.digitalbook.model.Payment;
import com.digitalbook.model.User;
import com.digitalbook.repositary.AuthorRepositary;
import com.digitalbook.repositary.BookRepositary;
import com.digitalbook.repositary.PaymentRepositary;
import com.digitalbook.service.ReaderService;

@Service
public class ReaderServiceImpl implements ReaderService {

	@Autowired
	private BookRepositary bookRepository;

	@Autowired
	private AuthorRepositary userRepositary;

	@Autowired
	private PaymentRepositary paymentRepositary;

	@Override
	public Optional<BookDetails> getPurchasedBookByPayId(Integer paymentId) {
		Payment payment = paymentRepositary.getByPaymentId(paymentId);
		Optional<BookDetails> retrivedBook = bookRepository.findById(payment.getBookId());
		return retrivedBook;

	}

	@Override
	public Payment buyBook(Payment payment, Integer bookId) {
		BookDetails bookdetails = bookRepository.getById(bookId);
		if (bookdetails.getPrice().equals(payment.getPrice())) {
			payment.setBookId(bookId);
			payment.setUserName(payment.getUserName());
			payment.setEmail(payment.getEmail());
			payment.setPrice(bookdetails.getPrice());
			Random random = new Random();
			payment.setPaymentId(random.nextInt());
			paymentRepositary.save(payment);
			return payment;
		}
		return payment;
	}

	@Override
	public List<BookDetails> searchbooks(String category, String authorname, BigDecimal price, String publisherName) {

		List<BookDetails> booklist = bookRepository.findAll();
		return booklist.stream().filter(n -> n.getCategory().equals(category)
				|| n.getAuthorName().equalsIgnoreCase(authorname) || n.getPrice().equals(price))
				.collect(Collectors.toList());
	}
}
