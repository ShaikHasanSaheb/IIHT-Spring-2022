package com.digitalbook.service;

import com.digitalbook.model.User;

public interface AutherService {
	
	User createUserByAdmin(User user);
	
	User createAdmin(User user);

}
