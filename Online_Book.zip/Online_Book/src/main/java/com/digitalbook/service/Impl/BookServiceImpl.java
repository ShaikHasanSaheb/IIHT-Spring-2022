package com.digitalbook.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalbook.exception.ResourceNotFoundException;
import com.digitalbook.model.BookDetails;
import com.digitalbook.repositary.BookRepositary;
import com.digitalbook.service.BookService;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepositary bookRepository;

	@Override
	public BookDetails addBook(BookDetails bookDetails) {
		bookRepository.save(bookDetails);
		return bookDetails;
	}

	@Override
	public BookDetails updateBookDetails(BookDetails book, Integer id) {
		BookDetails existingBook = bookRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));
		existingBook.setTitle(book.getTitle());
		existingBook.setCategory(book.getCategory());
		existingBook.setImage(book.getImage());
		existingBook.setPrice(book.getPrice());
		existingBook.setPublisherName(book.getPublisherName());
		existingBook.setActive(book.getActive());
		existingBook.setAuthorName(book.getAuthorName());
		existingBook.setContent(book.getContent());
		bookRepository.save(existingBook);
		return existingBook;
	}

	@Override
	public List<BookDetails> getallBooks() {
		return bookRepository.findAll();
	}

	@Override
	public Optional<BookDetails> getBook(Integer id) {
		return bookRepository.findById(id);
	}

	@Override
	public void deleteBook(Integer id) {
		bookRepository.deleteById(id);
	}
}
