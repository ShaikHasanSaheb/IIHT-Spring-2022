package com.digitalbook.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalbook.model.User;
import com.digitalbook.repositary.AuthorRepositary;
import com.digitalbook.service.AutherService;

@Service
public class AutherServiceImpl implements AutherService {

	@Autowired
	private AuthorRepositary autherRepositary;

	@Override
	public User createAdmin(User userDetails) {
		if (userDetails.getUserName() != null && userDetails.getEmail() != null) {
			userDetails.setRoleType("ROLE_ADMIN");
			User savedUserList = autherRepositary.save(userDetails);
			return savedUserList;
		}
		return userDetails;
	}

	@Override
	public User createUserByAdmin(User userDetails) {
		userDetails.setRoleType("ROLE_USER");
		User savedUserList = autherRepositary.save(userDetails);
		return savedUserList;

	}

}
