package com.digitalbook.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "Payment.findByUserName", query = "select p from Payment p where p.userName = ?1")
@NamedQuery(name = "Payment.getByPaymentId", query = "select p from Payment p where p.paymentId = ?1")
public class Payment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String userName;
	private String email;
	private Integer paymentId;
	private Integer bookId;
	private Integer price;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Payment(Integer id, String userName, String email, Integer paymentId, Integer bookId, Integer price) {
		super();
		this.id = id;
		this.userName = userName;
		this.email = email;
		this.paymentId = paymentId;
		this.bookId = bookId;
		this.price = price;
	}

	public Payment() {
		super();
	}

}
