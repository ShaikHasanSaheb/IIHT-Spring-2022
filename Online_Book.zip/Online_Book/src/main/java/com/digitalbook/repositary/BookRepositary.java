package com.digitalbook.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.digitalbook.model.BookDetails;

@Repository
public interface BookRepositary extends JpaRepository<BookDetails, Integer> {

	
}
