package com.digitalbook.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbook.model.User;
import com.digitalbook.service.AutherService;

@RestController
@RequestMapping("api/v1/digital_book/author")
public class AuthorController {

	@Autowired
	private AutherService autherService;

	@PostMapping("/createAdmin")
	private User createAdmin(@RequestBody User user) {
		User createdAdminDetails = autherService.createAdmin(user);
		return createdAdminDetails;
	}

	@PostMapping("/createUserByAdmin")
	private User createUser(@RequestBody User user) {
		User createdUserDetails = autherService.createUserByAdmin(user);
		return createdUserDetails;
	}
}
