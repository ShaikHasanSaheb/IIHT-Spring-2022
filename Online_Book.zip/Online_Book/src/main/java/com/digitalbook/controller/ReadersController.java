package com.digitalbook.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbook.model.BookDetails;
import com.digitalbook.model.Payment;
import com.digitalbook.service.ReaderService;

@RestController
@RequestMapping("api/v1/digital_book/author")
public class ReadersController {

	@Autowired
	private ReaderService readerService;

	@GetMapping("/searchbooks/{category}/{authorname}/{price}/{publisherName}")
	public List<BookDetails> searchBooks(@PathVariable String category, @PathVariable String authorname,
			@PathVariable BigDecimal price, @PathVariable String publisherName) {
		return readerService.searchbooks(category, authorname, price, publisherName);
	}

	@PostMapping("/buyTheBook/{bookId}")
	private Payment buyBook(@RequestBody Payment payment, @PathVariable Integer bookId) {
		Payment buyBook = readerService.buyBook(payment, bookId);
		return buyBook;
	}

	@GetMapping("/purchasedBook/{paymentId}")
	public Optional<BookDetails> getpurchasedBookByPayId(@PathVariable Integer paymentId) {
		Optional<BookDetails> book = readerService.getPurchasedBookByPayId(paymentId);
		return book;
	}
	
}
